<!-- Notifications: style can be found in dropdown.less -->
<li class="dropdown notifications-menu">
	<a href="#"	class="dropdown-toggle" data-toggle="dropdown"> <i class="fa fa-warning"></i> </a> <!-- <span class="label label-warning">10</span> -->
	<ul class="dropdown-menu">
		<li class="header">You have 0 notifications</li>
		<li>
			<!-- inner menu: contains the actual data -->
			<ul class="menu">
				<!-- 
				<li><a href="#"> <i class="ion ion-ios7-people info"></i> 5 new
						members joined today
				</a></li>
				-->
			</ul>
		</li>
		<li class="footer"><a href="#">View all</a></li>
	</ul></li>