toasty
======

Toasty - A jQuery plugin for message toasts

Go to http://clifordtube.com/toasty/index.html for Demo and API reference
